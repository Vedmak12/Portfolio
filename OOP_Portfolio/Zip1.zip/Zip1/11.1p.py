import psutil
import os

class CounterClass:
    def __init__(self, names):
        self._counts = 0
        self._names = names

    @property
    def getname(self):
        return self._names

    @property
    def setname(self, values):
        self._names = values

    @property
    def counterticks(self):
        return self._counts

    def incrementtick(self):
        self._counts += 1

    def resettick(self):
        self._counts = 0


class ClockClass:
    def __init__(self):
        self._sec = CounterClass("sec")
        self._min = CounterClass("min")
        self._hrs = CounterClass("hrs")

    def increment_the_clock(self):
        self._sec.incrementtick()
        if self._sec.counterticks == 60:
            self._sec.resettick()
            self._min.incrementtick()

        if self._min.counterticks == 60:
            self._min.resettick()
            self._hrs.incrementtick()

        if self._hrs.counterticks == 24:
            self._hrs.resettick()

    def show(self):
        return f"{self._hrs.counterticks:02d} : {self._min.counterticks:02d} : {self._sec.counterticks:02d}"

    def memory_usage(self):
        process = psutil.Process(os.getpid())
        mem_info = process.memory_info()
        return mem_info.rss  # Return the RSS (Resident Set Size) memory usage



if __name__ == "__main__":
    newClock = ClockClass()

    for i in range(86400):
        newClock.increment_the_clock()
        print(newClock.show())

    # Print memory usage after the clock has been incremented for 86400 ticks
    print(f"Memory Usage: {newClock.memory_usage() / (1024 * 1024):.2f} MB")  # Print memory usage in MB    
