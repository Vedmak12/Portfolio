﻿namespace CounterTask
{
    public class Counter
    {
        private int _Count;
        private string _Name;

        public Counter(string name)
        {
            _Name = name;
            _Count = 0;
        }

        public string Name
        {
            get => _Name;
            set => _Name = value;
        }

        public int GetCount()
        {
            return _Count;
        }

        public void Increment()
        {
            _Count++;
        }

        public void Reset()
        {
            _Count = 0;
        }
    }
}
