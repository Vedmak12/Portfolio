﻿namespace CounterTask
{
    public class Clock
    {
        private Counter hours;
        private Counter minutes;
        private Counter seconds;
        private bool is12HourFormat;

        public Clock(int studentIDLastDigit)
        {
            hours = new Counter("Hours");
            minutes = new Counter("Minutes");
            seconds = new Counter("Seconds");
            is12HourFormat = studentIDLastDigit <= 5;
        }

        public void Tick()
        {
            seconds.Increment();
            if (seconds.GetCount() >= 60)
            {
                seconds.Reset();
                minutes.Increment();
            }

            if (minutes.GetCount() >= 60)
            {
                minutes.Reset();
                hours.Increment();
            }

            int hourLimit = is12HourFormat ? 12 : 24;
            if (hours.GetCount() >= hourLimit)
            {
                hours.Reset();
            }
        }

        public void Reset()
        {
            hours.Reset();
            minutes.Reset();
            seconds.Reset();
        }

        public string GetTime()
        {
            int hour = hours.GetCount();
            string period = is12HourFormat && hour >= 12 ? "PM" : "AM";
            hour = is12HourFormat ? (hour == 0 ? 12 : hour > 12 ? hour - 12 : hour) : hour;
            return $"{hour:00}:{minutes.GetCount():00}:{seconds.GetCount():00} {period}";
        }
    }
}
