﻿using System.Diagnostics;

namespace CounterTask
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Clock myClock = new Clock(4); // Example with 12-hour format

            for (int i = 0; i < 3660; i++) // Tick the clock 3661 times
            {
                myClock.Tick();
                Console.WriteLine(myClock.GetTime());
            }

            Process proc = Process.GetCurrentProcess();
            Console.WriteLine("Current process: {0}", proc.ToString());
            Console.WriteLine("Physical memory usage: {0} bytes", proc.WorkingSet64);
            Console.WriteLine("Peak physical memory usage: {0} bytes", proc.PeakWorkingSet64);
        }
    }
}
