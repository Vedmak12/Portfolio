﻿using NUnit.Framework;

[TestFixture]
public class ClockTests
{
    [Test]
    public void Clock_Tick_AdvancesTime()
    {
        Clock clock = new Clock(4); // 12-hour format
        clock.Tick();
        Assert.AreEqual("00:00:01", clock.GetTime());
    }

    [Test]
    public void Clock_Reset()
    {
        Clock clock = new Clock(4);
        clock.Tick();
        clock.Reset();
        Assert.AreEqual("00:00:00", clock.GetTime());
    }

    [Test]
    public void Clock_Handles12HourFormat()
    {
        Clock clock = new Clock(4); // 12-hour format
        for (int i = 0; i < 43200; i++) // 12 hours in seconds
        {
            clock.Tick();
        }
        Assert.AreEqual("12:00:00", clock.GetTime());
    }

    [Test]
    public void Clock_Handles24HourFormat()
    {
        Clock clock = new Clock(8); // 24-hour format
        for (int i = 0; i < 86400; i++) // 24 hours in seconds
        {
            clock.Tick();
        }
        Assert.AreEqual("00:00:00", clock.GetTime());
    }
}
