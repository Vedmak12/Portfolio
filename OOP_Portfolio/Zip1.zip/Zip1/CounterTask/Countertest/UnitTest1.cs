using CounterTask;
namespace Countertest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }




            [Test]
            public void Counter_InitializesAtZero()
            {
                Counter counter = new Counter();
                Assert.AreEqual(0, counter.GetCount());
            }

            [Test]
            public void Counter_IncrementOnce()
            {
                Counter counter = new Counter();
                counter.Increment();
                Assert.AreEqual(1, counter.GetCount());
            }

            [Test]
            public void Counter_IncrementMultipleTimes()
            {
                Counter counter = new Counter();
                counter.Increment();
                counter.Increment();
                counter.Increment();
                Assert.AreEqual(3, counter.GetCount());
            }

            [Test]
            public void Counter_Reset()
            {
                Counter counter = new Counter();
                counter.Increment();
                counter.Reset();
                Assert.AreEqual(0, counter.GetCount());
            }
        }
    
}
