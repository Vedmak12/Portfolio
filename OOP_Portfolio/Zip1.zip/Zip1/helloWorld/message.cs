﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace helloWorld
{
    internal class message
    {
        private string _text;

        public message(string text)
        {
            _text = text;
        }
        public void Print()
        {
            Console.WriteLine(_text);
        }
      
    }
}
