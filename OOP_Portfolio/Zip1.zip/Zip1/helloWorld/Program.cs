﻿using System.Security.Cryptography.X509Certificates;

namespace helloWorld
{
    internal class Program
    {
        static void Main(string[] args)
        {


            message myMessage = new message("Hello World, Greetings from the Message object. My student id is 104762184.");

            List<message> messages = new List<message>();
            messages.Add(new message("Hi Anjali, how are you?"));
            messages.Add(new message("Hi IronMan, how are you?"));
            messages.Add(new message("Hi Deadpool, how are you?"));
            messages.Add(new message("Welcome Admin"));
            messages.Add(new message("Welcome, nice to me you."));

            myMessage.Print();

            Console.WriteLine("Enter Name");
            string name = Console.ReadLine();
            if (name.ToLower() == "anjali")
            {
                messages[0].Print();
            }
            else if (name.ToLower() == "ironman")
            {
                messages[1].Print();
            }
            else if (name.ToLower() == "deadpool")
            {
                messages[2].Print();
            }
            else if (name.ToLower() == "ved")
            {
                messages[3].Print();
            }
            else
            {
                messages[4].Print();
            }

        }
    }
}
