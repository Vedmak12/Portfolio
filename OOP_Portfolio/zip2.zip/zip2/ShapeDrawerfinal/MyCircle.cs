﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyGame;
using SplashKitSDK;

namespace ShapeDrawer
{
    public class MyCircle : Shape
    {
        private int _radius;
        public int Radius
        {
            get { return _radius; }
            set { _radius = value; }
        }
        public MyCircle() : this(Color.Chocolate, 184)
        {

        }

        public MyCircle(Color color, int _radius) : base(color)
        {
            Radius = _radius;
        }
        public override void Draw()
        {
            if (Selected)
            {
                DrawOutline(5);
            }
            SplashKit.FillCircle(Color, X, Y, _radius);
        }
        public override void DrawOutline(int extra)
        {
            {
                SplashKit.DrawCircle(Color.Black, X, Y, _radius + 2);
            }
        }

        public override bool IsAt(Point2D pt)
        {
            if (pt.X >= _radius && pt.Y >= _radius)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override void SaveTo(StreamWriter writer)
        {
            writer.WriteLine("Circle");
            base.SaveTo(writer);
            writer.WriteLine(Radius);
            
        }
        public override void LoadFrom(StreamReader reader)
        {
            base.LoadFrom(reader);
            Radius = reader.ReadInteger();
            


        }
    }
}
