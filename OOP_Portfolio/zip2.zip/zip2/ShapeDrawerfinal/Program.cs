using SplashKitSDK;

namespace ShapeDrawer
{
    public class Program
    {
        private enum ShapeKind
        {
            Rectangle,
            Circle,
            Line
        }

        public static void Main()
        {
            Drawing myDrawing = new Drawing();
            Window window = new Window("Shape Drawer", 800, 600);
            ShapeKind kindToAdd = ShapeKind.Circle;

            string studentID = "104762184"; // Adjust your student ID here
            int lastDigit = int.Parse(studentID[^1].ToString());
            int numberOfLinesToAdd = lastDigit == 0 ? 5 : lastDigit;
            int linesAdded = 0; // Initialize outside the loop

            do
            {
                SplashKit.ProcessEvents();
                SplashKit.ClearScreen();

                if (SplashKit.KeyDown(KeyCode.RKey)) kindToAdd = ShapeKind.Rectangle;
                if (SplashKit.KeyDown(KeyCode.CKey)) kindToAdd = ShapeKind.Circle;
                if (SplashKit.KeyDown(KeyCode.LKey)) kindToAdd = ShapeKind.Line;

                if (SplashKit.MouseClicked(MouseButton.LeftButton))
                {
                    Shape newShape;

                    switch (kindToAdd)
                    {
                        case ShapeKind.Circle:
                            newShape = new MyCircle();
                            newShape.X = SplashKit.MouseX();
                            newShape.Y = SplashKit.MouseY();
                            myDrawing.AddShape(newShape);
                            break;

                        case ShapeKind.Line:
                            // Add lines only if we haven't added the maximum yet
                            if (linesAdded < numberOfLinesToAdd)
                            {
                                newShape = new MyLine();
                                newShape.X = SplashKit.MouseX();
                                newShape.Y = SplashKit.MouseY();
                                myDrawing.AddShape(newShape);
                                linesAdded++; // Increment lines added
                            }
                            continue; // Skip the rest of the loop for Line

                        default:
                            newShape = new MyRectangle();
                            newShape.X = SplashKit.MouseX();
                            newShape.Y = SplashKit.MouseY();
                            myDrawing.AddShape(newShape);
                            break;
                    }
                }

                // Reset linesAdded if the user changes the shape to something other than Line
                if (kindToAdd != ShapeKind.Line)
                {
                    linesAdded = 0; // Reset when changing shape
                }

                if (SplashKit.KeyDown(KeyCode.SpaceKey))
                {
                    myDrawing.Background = Color.Random();
                }

                if (SplashKit.MouseClicked(MouseButton.RightButton))
                {
                    myDrawing.SelectShapesAt(SplashKit.MousePosition());
                }

                if (SplashKit.KeyDown(KeyCode.DeleteKey) || SplashKit.KeyDown(KeyCode.BackspaceKey))
                {
                    foreach (Shape s in myDrawing.SelectedShapes)
                    {
                        myDrawing.RemoveShape(s);
                    }
                }

                if (SplashKit.KeyDown(KeyCode.SKey))
                {
                    myDrawing.Save(@"C:\Users\vedma\Desktop\OOP\ShapeDrawer2week 4\TestDrawing.txt");
                }

                if (SplashKit.KeyDown(KeyCode.OKey))
                {
                    try
                    {
                        myDrawing.load(@"C:\Users\vedma\Desktop\OOP\ShapeDrawer2week 4\TestDrawing.txt");
                    }
                    catch (Exception e)
                    {
                        Console.Error.WriteLine("Error Loading File: {0}", e.Message);
                    }
                }

                myDrawing.Draw();
                SplashKit.RefreshScreen();
            } while (!window.CloseRequested);
        }
    }
}
