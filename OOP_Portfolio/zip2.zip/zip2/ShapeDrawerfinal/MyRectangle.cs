﻿using System;
using System.Collections.Generic;
//using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyGame;
using SplashKitSDK;

namespace ShapeDrawer
{
    public class MyRectangle : Shape
    {
        private int _width;
        private int _height;
        public int Width
        {
            get { return _width; }
            set { _width = value; }
        }
        public int Height
        {
            get { return _height; }
            set { _height = value; }
        }

        public MyRectangle(Color color, float x, float y, int width, int height) : base(color)
        {
            _width = width;
            _height = height;
            X = x;
            Y = y;
        }
        public MyRectangle() : this(Color.Chocolate, 0.0f, 0.0f, 184, 184)
        {

        }
        public override void Draw()
        {
            SplashKit.FillRectangle(Color, X, Y, _width, _height);
            if (Selected)
            {
                int extra = 9;
                DrawOutline(extra);
            }
        }


        public override void DrawOutline(int extra)
        {
            SplashKit.DrawRectangle(Color.Black, X - extra, Y - extra, Width + 2 * extra, Height + 2 * extra);
        }

        public override bool IsAt(Point2D pt)
        {
            if (pt.X >= X && pt.Y >= Y && pt.X <= X + _width && pt.Y <=
            Y + _height)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override void SaveTo(StreamWriter writer)
        {
            writer.WriteLine("Rectangle");
            base.SaveTo(writer);
            writer.WriteLine(Width);
            writer.WriteLine(Height);
        }
        public override void LoadFrom(StreamReader reader)
        {
            base.LoadFrom(reader);
            Width = reader.ReadInteger();
            Height = reader.ReadInteger();

            
        }


    }
}
