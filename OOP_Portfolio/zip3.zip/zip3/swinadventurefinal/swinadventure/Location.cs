﻿public class Location : GameObject, IHaveInventory
	{

		private Inventory _inventory;
		private List<Path> _paths;

	public Location(string[] ids, string name, string description) : base(ids, name, description)
	{
		_inventory = new Inventory();
		_paths = new List<Path>();
	}



	public void AddPath(Path path)
			{
				_paths.Add(path);
			}

	public Path GetPath(string direction)
	{
		foreach (Path path in _paths)
		{
			// Only return if a matching path is found
			if (path.AreYou(direction))
			{
				return path;
			}
		}

		// Return null after checking all paths and finding no match
		return null;
	}

	public GameObject Locate(string id)
		{

			if (AreYou(id))
			{
				return this;
			}
			else if (_inventory.HasItem(id))
			{
				return _inventory.Fetch(id);
			}
			// might be here
			else
			{
				return null;
			}
		}
	public override string FullDescription
	{
		get
		{
			return $"You are in {Name}\n{Description}\nIn this room you can see:\n{_inventory.ItemList}";
		}
	}

	public Inventory Inventory

		{
			get
			{
				return _inventory;
			}
		}

		public Item FetchItem(string id)
		{
			return _inventory.Fetch(id);
		}
    string IHaveInventory.Name
    {
        get
        {
            return Name;
        }
    }
}

