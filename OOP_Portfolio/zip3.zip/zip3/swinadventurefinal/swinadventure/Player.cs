﻿public class Player : GameObject, IHaveInventory
{
    private Inventory _inventory;
    private Location _currentLocation;
    public Player(string name, string desc,Location startingLocation) : base(new string[] { "me", "inventory" }, name, desc)
    {
        _inventory = new Inventory();
        _currentLocation = startingLocation;
    }

    public Inventory Inventory
    {
        get { return _inventory; }
    }
    public Location CurrentLocation
    {
        get { return _currentLocation; }
        set { _currentLocation = value; }
    }
    public override string FullDescription
    {
        get
        {
            return $"You are {Name}, {base.FullDescription}\nYou are carrying:\n{_inventory.ItemList}";
        }
    }

	public GameObject Locate(string id)
	{
		// Check if the player is being referred to
		if (AreYou(id))
		{
			return this;
		}
		// Check if the item is in the player's inventory
		else if (_inventory.HasItem(id))
		{
			return _inventory.Fetch(id);
		}
		// Check if the item is in the location
		else if (_currentLocation != null)
		{
			return _currentLocation.Locate(id); // Return the result of location.Locate(id)
		}
		// If not found, return null
		else
		{
			return null;
		}
	}
	public bool Move(string direction)
	{
		Path path = _currentLocation.GetPath(direction);

		if (path != null)
		{
			_currentLocation = path.Destination;
			return true;
		}
		else
		{
			return false;
		}
	}

}

