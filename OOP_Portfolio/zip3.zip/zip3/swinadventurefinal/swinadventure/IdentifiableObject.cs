﻿using System;
using System.Collections.Generic;
using System.Linq;

public class IdentifiableObject
{
    private List<string> _identifiers;

    public IdentifiableObject(string[] idents)
    {
        _identifiers = new List<string>();
        foreach (var id in idents)
        {
            AddIdentifier(id);
        }
    }

    public bool AreYou(string id)
    {
        return _identifiers.Contains(id.ToLower());
    }

    public string FirstId
    {
        get
        {
            return _identifiers.FirstOrDefault() ?? string.Empty;
        }
    }

    public void AddIdentifier(string id)
    {
        _identifiers.Add(id.ToLower());
    }

    public void PrivilegeEscalation(string pin)
    {
        if (pin == "2184") 
        {
            _identifiers[0] = "1"; 
        }
    }
}
