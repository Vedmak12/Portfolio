﻿namespace swinadventure
{
    public class CommandProcessor
    {
        private List<Command> _commands;

        public CommandProcessor() 
        {
            _commands = new List<Command>();
            _commands.Add(new LookCommand());
            _commands.Add(new MoveCommand());
        }

        public string ExecuteCommand(Player P, string[] text)
        {
            if (text==null || text.Length == 0)
            {
                return "command not found.";
            }
            foreach (Command cmd in _commands)
            {
                if (cmd.AreYou(text[0]))
                {
                    return cmd.Execute(P, text);
                }
               
            }
            return "command not found";
        }
    }
    }

