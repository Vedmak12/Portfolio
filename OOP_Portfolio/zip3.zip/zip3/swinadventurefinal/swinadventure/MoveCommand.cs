﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace swinadventure
{
	public class MoveCommand : Command
	{
		public MoveCommand() : base(new string[] { "move", "go", "head", "leave" }){

		}

		public override string Execute(Player player, string[] text)
		{
			if (text.Length != 2)
			{
				return " i dont know how to move like that";
			}

			string direction = text[1];
			if (player.Move(direction))
			{
				return "you move " + direction+ "."+ player.CurrentLocation.FullDescription;
			}
			else
			{
				return "there is no path to the " + direction + ".";
			}
		}
	}
}
