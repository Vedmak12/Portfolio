﻿namespace swinadventure
{
	internal class Program
	{
		static void Main(string[] args)
		{
			// Setup Player
			Console.WriteLine("Please enter your Name:");
			var name = Console.ReadLine();
			Console.WriteLine("Please enter your Description:");
			var description = Console.ReadLine();
			Player player1 = new Player(name, description, null);

			Console.WriteLine("Hello " + name);

			// Create Items
			Item sword = new Item(new string[] { "sword", "blade" }, "a sword", "A sharp bronze sword.");
			Item shovel = new Item(new string[] { "shovel", "spade" }, "a shovel", "A sturdy shovel.");
			Bag bag = new Bag(new string[] { "bag", "sack" }, "a small bag", "A small leather bag.");
			Item gem = new Item(new string[] { "gem", "jewel" }, "a bright gem", "A sparkling red gem.");

			// Add Items to Inventory and Bag
			player1.Inventory.Put(sword);
			player1.Inventory.Put(shovel);
			player1.Inventory.Put(bag);
			bag.Inventory.Put(gem);

			// Setup Locations
			Location home = new Location(new string[] { "home" }, "Home", "Your cozy home.");
			Location forest = new Location(new string[] { "forest" }, "Forest", "A dark and spooky forest.");
			Location town = new Location(new string[] { "town" }, "Town", "A peaceful town.");

			// Setup Paths between Locations
			Path pathToForest = new Path(new string[] { "north", "forest" }, forest);
			Path pathToTown = new Path(new string[] { "south", "town" }, town);
			Path pathBackHome = new Path(new string[] { "west", "home" }, home);
			Path pathBackHome2 = new Path(new string[] { "east", "home" }, home);
			// Add Paths to Locations
			home.AddPath(pathToForest);    // Go north from home to forest
			forest.AddPath(pathBackHome);  // Go south from forest to home
			forest.AddPath(pathToTown);    // Go south from forest to town
			town.AddPath(pathBackHome2);

			// Set Player's starting location to home
			player1.CurrentLocation = home;
            CommandProcessor commandProcessor = new CommandProcessor();
            // Game Loop
            Console.WriteLine("Type 'look' to examine your surroundings, 'move [direction]' to move, or 'exit' to quit.");
			while (true)
			{
				Console.Write("Enter a Command: ");
				string input = Console.ReadLine().ToLower();

				if (input == "exit")
				{
					break;
				}

				// Split command into words
				string[] command = input.Split(' ');

               
               
                string result = commandProcessor.ExecuteCommand(player1, command);
				Console.WriteLine(result);
            }
		}
	}
}
