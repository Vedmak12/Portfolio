﻿public class LookCommand : Command
{
    public LookCommand() : base(new string[] { "look" }) { }

    public override string Execute(Player p, string[] text)
    {
        if (text.Length == 1 && text[0] == "look")
        {
            return p.CurrentLocation.ShortDescription;
        }

        if (text.Length != 3 && text.Length != 5)
        {
            return "I don't know how to look like that";
        }

        if (text[0] != "look")
        {
            return "Error in look input";
        }

        
        if (text[1] != "at")
        {
            return "What do you want to look at?";
        }

        
        GameObject container;
        if (text.Length == 3)
        {
            container = p; 
        }
        else
        {
            container = FetchContainer(p, text[4]); 
        }

        
        if (container == null)
        {
            return $"I cannot find the {text[4]}";
        }

        
        return LookAtIn(text[2], container);
    }

    
    private GameObject FetchContainer(Player p, string containerId)
    {
        return p.Locate(containerId); 
    }

	
	private string LookAtIn(string thingId, GameObject container)
	{
		IHaveInventory containerWithInventory = container as IHaveInventory;

		if (containerWithInventory == null)
		{
			return $"{container.Name} is not a container";
		}

		GameObject item = containerWithInventory.Locate(thingId);

		if (item != null)
		{
			return item.FullDescription;
		}

		
		if (container == containerWithInventory)
		{
			return $"I cannot find the {thingId}";
		}

		return $"I cannot find the {thingId} in the {container.Name}";
	}

}
