﻿public class Path : IdentifiableObject
{
	private Location _destination;
	public Location Destination
	{
		get { return _destination; }
	}

	public Path(string[] ids, Location destination) : base(ids)
	{
		_destination = destination;
	}
}
