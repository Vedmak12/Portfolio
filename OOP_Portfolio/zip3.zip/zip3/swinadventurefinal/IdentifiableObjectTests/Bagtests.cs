﻿using NUnit.Framework;

[TestFixture]
public class BagTests
{
    private Bag _outerBag;
    private Bag _innerBag;
    private Item _gem;

    [SetUp]
    public void Setup()
    {
        _outerBag = new Bag(new string[] { "outer bag" }, "a large bag", "A large outer bag.");
        _innerBag = new Bag(new string[] { "inner bag" }, "a small bag", "A small inner bag.");
        _gem = new Item(new string[] { "gem" }, "a shiny gem", "A shiny precious gem.");
        _outerBag.Inventory.Put(_innerBag);
        _innerBag.Inventory.Put(_gem);
    }

    [Test]
    public void TestBagLocatesItems()
    {
        Assert.AreEqual(_gem, _innerBag.Locate("gem"));
    }

    [Test]
    public void TestBagLocatesItself()
    {
        Assert.AreEqual(_outerBag, _outerBag.Locate("outer bag"));
    }

    [Test]
    public void TestBagLocatesNothing()
    {
        Assert.IsNull(_outerBag.Locate("gem"));
    }

    [Test]
    public void TestBagFullDescription()
    {
        string expectedDescription = "In the a small bag you see:\n\ta shiny gem (gem)";
        Assert.AreEqual(expectedDescription, _innerBag.FullDescription);
    }

    [Test]
    public void TestBagInBag()
    {
        Assert.AreEqual(_innerBag, _outerBag.Locate("inner bag"));
        Assert.IsNull(_outerBag.Locate("gem"));
    }
    [Test]
    public void TestBagWithPrivilegedItem()
    {
        
        _innerBag.PrivilegeEscalation(_gem.FirstId); 
        Assert.IsNull(_outerBag.Locate("gem")); 
    }
}
