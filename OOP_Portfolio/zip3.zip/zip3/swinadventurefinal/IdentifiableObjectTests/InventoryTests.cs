﻿using NUnit.Framework;

[TestFixture]
public class InventoryTests
{
    private Inventory _inventory;
    private Item _sword;
    private Item _shield;

    [SetUp]
    public void Setup()
    {
        _inventory = new Inventory();
        _sword = new Item(new string[] { "sword" }, "a sword", "A sharp blade.");
        _shield = new Item(new string[] { "shield" }, "a shield", "A strong shield.");
        _inventory.Put(_sword);
        _inventory.Put(_shield);
    }

    [Test]
    public void TestInventoryHasItems()
    {
        Assert.IsTrue(_inventory.HasItem("sword"));
        Assert.IsTrue(_inventory.HasItem("shield"));
        Assert.IsFalse(_inventory.HasItem("gem"));
    }

    [Test]
    public void TestInventoryFetchItem()
    {
        Assert.AreEqual(_sword, _inventory.Fetch("sword"));
        Assert.AreEqual(_shield, _inventory.Fetch("shield"));
    }

    [Test]
    public void TestInventoryTakeItem()
    {
        Assert.AreEqual(_sword, _inventory.Take("sword"));
        Assert.IsFalse(_inventory.HasItem("sword"));
    }

    [Test]
    public void TestInventoryItemList()
    {
        string expectedItemList = "\ta sword (sword)\n\ta shield (shield)";
        Assert.AreEqual(expectedItemList, _inventory.ItemList);
    }
}
