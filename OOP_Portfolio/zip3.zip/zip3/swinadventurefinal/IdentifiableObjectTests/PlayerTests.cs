﻿using NUnit.Framework;

[TestFixture]
public class PlayerTests
{
    [Test]
    public void TestPlayerIsIdentifiable()
    {
        Player player = new Player("Fred", "a mighty programmer",null);
        Assert.IsTrue(player.AreYou("me"));
        Assert.IsTrue(player.AreYou("inventory"));
    }

    [Test]
    public void TestPlayerLocatesItems()
    {
        Player player = new Player("Fred", "a mighty programmer",null);
        Item item = new Item(new string[] { "sword" }, "a bronze sword", "a shiny sword");
        player.Inventory.Put(item);
        Assert.AreEqual(item, player.Locate("sword"));
    }

    [Test]
    public void TestPlayerLocatesItself()
    {
        Player player = new Player("Fred", "a mighty programmer",null);
        Assert.AreEqual(player, player.Locate("me"));
        Assert.AreEqual(player, player.Locate("inventory"));
    }

    [Test]
    public void TestPlayerLocatesNothing()
    {
        Player player = new Player("Fred", "a mighty programmer",null);
        Assert.IsNull(player.Locate("nonexistent"));
    }

    [Test]
    public void TestPlayerFullDescription()
    {
        Player player = new Player("Fred", "a mighty programmer",null);
        Item item1 = new Item(new string[] { "shovel" }, "a shovel", "a mighty fine shovel");
        Item item2 = new Item(new string[] { "sword" }, "a bronze sword", "a shiny sword");
        player.Inventory.Put(item1);
        player.Inventory.Put(item2);

        string expectedDescription = "You are Fred, a mighty programmer\nYou are carrying:\n\ta shovel (shovel)\n\ta bronze sword (sword)";
        Assert.AreEqual(expectedDescription, player.FullDescription);
    }
}
