﻿using NUnit.Framework;

[TestFixture]
public class TestLocation
{
	private Location location;
	private Player player;
	private Item sword;

	[SetUp]
	public void Setup()
	{
		// Use "room" and "here" as part of the identifiers
		location = new Location(new string[] { "a conflict", "room", "here" }, "In World", null);
		player = new Player("Ved", "the student", null);
		sword = new Item(new string[] { "sword" }, "a Sword", "a sharp Sword");

		location.Inventory.Put(sword);
		player.CurrentLocation = location;
	}


	// Test 1: Location can identify itself
	[Test]
	public void TestLocationCanIdentifyItself()
	{
		
		Assert.That(location.Locate("room"), Is.SameAs(location));

		
		Assert.That(location.Locate("here"), Is.SameAs(location));
	}

	// Test 2: Location can locate items it contains
	[Test]
	public void TestLocationCanLocateItemInInventory()
	{
		
		Assert.That(location.Locate("sword"), Is.SameAs(sword));
	}

	// Test 3: Player can locate items in their location
	
	[Test]
	public void TestPlayerCanLocateItemInLocation()
	{
		// Player should be able to locate the sword in the location's inventory
		Assert.That(player.Locate("sword"), Is.SameAs(sword));
	}


}
