﻿using NUnit.Framework;

namespace swinadventure.tests
{
    [TestFixture]
    public class CommandTests
    {
        private Player _player;
        private CommandProcessor _commandProcessor;
        private Location _home;
        private Location _forest;
        private Item _sword;
        private Item _shovel;
        private Bag _bag;
        private Item _gem;

        [SetUp]
        public void SetUp()
        {
            // Initialize the Player
            _player = new Player("Test Player", "A brave adventurer", null);


            _player = new Player("Test Player", "A brave adventurer", null);
            _home = new Location(new string[] { "home" }, "Home", "Your cozy home.");
            _forest = new Location(new string[] { "forest" }, "Forest", "A dark forest.");
            Path pathToForest = new Path(new string[] { "north" }, _forest);
            _home.AddPath(pathToForest);
            _player.CurrentLocation = _home;

            // Initialize Items
            _sword = new Item(new string[] { "sword" }, "A sword", "A sharp sword.");
            _shovel = new Item(new string[] { "shovel" }, "A shovel", "A sturdy shovel.");
            _bag = new Bag(new string[] { "bag" }, "A small bag", "A leather bag.");
            _gem = new Item(new string[] { "gem" }, "A gem", "A sparkling red gem.");

            // Add Items to Player and Bag
            _player.Inventory.Put(_sword);
            _player.Inventory.Put(_shovel);
            _bag.Inventory.Put(_gem);
            _player.Inventory.Put(_bag);

            // Initialize Command Processor
            _commandProcessor = new CommandProcessor();

        }

        // CommandProcessor Tests
        [Test]
        public void TestCommandProcessorExecutesKnownCommand()
        {
            // Act
            string result = _commandProcessor.ExecuteCommand(_player, new string[] { "look","at", "me" });

            // Assert
            Assert.AreEqual(_player.FullDescription, result);
        }

        [Test]
        public void TestCommandProcessorHandlesUnknownCommand()
        {
            // Act
            string result = _commandProcessor.ExecuteCommand(_player, new string[] { "fly" });

            // Assert
            Assert.AreEqual("command not found", result);
        }

        [Test]
        public void TestCommandProcessorHandlesEmptyCommand()
        {
            // Act
            string result = _commandProcessor.ExecuteCommand(_player, new string[] { });

            // Assert
            Assert.AreEqual("command not found.", result);
        }

        // LookCommand Tests
        [Test]
        public void TestLookAtLocation()
        {
            // Arrange
            LookCommand lookCommand = new LookCommand();

            // Act
            
            string result = lookCommand.Execute(_player, new string[] { "look" , "at", "Home" });

            // Assert
            Assert.AreEqual(_player.CurrentLocation.FullDescription, result);
        }

        [Test]
        public void TestLookAtKnownObject()
        {
            // Arrange
            LookCommand lookCommand = new LookCommand();

            // Act
            string result = lookCommand.Execute(_player, new string[] { "look", "at", "sword" });

            // Assert
            Assert.AreEqual(_sword.FullDescription, result);
        }

        [Test]
        public void TestLookAtUnknownObject()
        {
            // Arrange
            LookCommand lookCommand = new LookCommand();

            // Act
            string result = lookCommand.Execute(_player, new string[] { "look", "at", "shield" });

            // Assert
            Assert.AreEqual("I cannot find the shield", result);
        }

        // MoveCommand Tests
        [Test]
        public void TestMoveToValidDirection()
        {
            // Arrange
            MoveCommand moveCommand = new MoveCommand();

            // Act
            string result = moveCommand.Execute(_player, new string[] { "move", "north" });

            // Assert
            Assert.AreEqual("you move north.You are in Forest\nA dark forest.\nIn this room you can see:\n", result);
            Assert.That(_forest,Is.EqualTo( _player.CurrentLocation));
        }

        [Test]
        public void TestMoveToInvalidDirection()
        {
            // Arrange
            MoveCommand moveCommand = new MoveCommand();

            // Act
            string result = moveCommand.Execute(_player, new string[] { "move", "south" });

            // Assert
            Assert.AreEqual("there is no path to the south.", result);
        }
    }
}

