﻿using NUnit.Framework;

[TestFixture]
public class PathTests
{
	private Location _home;
	private Location _forest;
	private Path _pathToForest;
	private Path _pathToHome;
	private Player _player;

	[SetUp]
	public void Setup()
	{
		// Initialize locations with consistent references
		_home = new Location(new string[] { "home" }, "Home", "Your cozy home.");
		_forest = new Location(new string[] { "forest" }, "Forest", "A dark and spooky forest.");

		// Create paths between locations
		_pathToForest = new Path(new string[] { "north", "forest" }, _forest);
		_pathToHome = new Path(new string[] { "south", "home" }, _home);  // Path back to home

		_home.AddPath(_pathToForest);  // Add path from home to forest
		_forest.AddPath(_pathToHome);  // Add path from forest back to home

		// Create player starting at home
		_player = new Player("Hero", "A brave adventurer", _home);
	}

	[Test]
	public void TestPlayerCanLeaveLocationWithValidPathIdentifier()
	{
		// Move player north to the forest
		_player.Move("north");
		Assert.AreEqual(_forest, _player.CurrentLocation, "Player should be in the forest.");

		// Move player back to home
		_player.Move("south");
		Assert.AreEqual(_home, _player.CurrentLocation, "Player should be back at home.");
	}



	[Test]
	public void TestPathCanMovePlayerToDestination()
	{
		// Move player north to the forest
		bool moved = _player.Move("north");
		Assert.IsTrue(moved, "Player should be able to move north.");
		Assert.AreEqual(_forest, _player.CurrentLocation, "Player should be in the forest now.");
	}

	[Test]
	public void TestGetPathFromLocation()
	{
		// Check if the path exists from home to forest
		Path path = _home.GetPath("north");
		Assert.IsNotNull(path, "Path to forest should exist.");
		Assert.AreEqual(_forest, path.Destination, "The destination of the path should be the forest.");
	}

	


	[Test]
	public void TestPlayerRemainsInSameLocationWithInvalidPathIdentifier()
	{
		// Player should start in home
		Assert.AreEqual(_home, _player.CurrentLocation, "Player should be at home initially.");

		// Attempt to move in an invalid direction
		bool moved = _player.Move("east");  // No path to the east
		Assert.IsFalse(moved, "Player should not be able to move east.");
		Assert.AreEqual(_home, _player.CurrentLocation, "Player should still be at home.");
	}

	[Test]
	public void TestGetPathFromLocationWithInvalidDirection()
	{
		// Attempt to get a path in an invalid direction
		Path path = _home.GetPath("east");
		Assert.IsNull(path, "No path should exist to the east from home.");
	}
}
