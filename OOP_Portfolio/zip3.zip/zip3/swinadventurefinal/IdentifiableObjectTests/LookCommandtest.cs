﻿using NUnit.Framework;

[TestFixture]
public class LookCommandTests
{
	private Player _player;
	private Item _gem;
	private Item _sword;
	private Bag _bag;
	private LookCommand _lookCommand;

	[SetUp]
	public void Setup()
	{
		_player = new Player("Ved Jay Makhijani", "104762184",null);
		_gem = new Item(new string[] { "gem" }, "a gem", "A shiny gem");
		_sword = new Item(new string[] { "sword" }, "a sword", "A sharp sword");
		_bag = new Bag(new string[] { "bag" }, "a leather bag", "A large leather bag");
		_lookCommand = new LookCommand();

		
		_player.Inventory.Put(_gem);
		_player.Inventory.Put(_bag);
		_bag.Inventory.Put(_sword);
	}

	[Test]
	
	public void TestLookAtMe()
	{
		string result = _lookCommand.Execute(_player, new string[] { "look", "at", "inventory" });
		string expected = "You are Ved Jay Makhijani, 104762184\nYou are carrying:\n\t" + "a gem (gem)\n\t" + "a leather bag (bag)";
		Assert.AreEqual(expected, result);
	}


	[Test]
	public void TestLookAtGem()
	{
		string result = _lookCommand.Execute(_player, new string[] { "look", "at", "gem" });
		Assert.AreEqual("A shiny gem", result);
	}

	[Test]
	
	public void TestLookAtUnk()
	{
		string result = _lookCommand.Execute(_player, new string[] { "look", "at", "ring" });
		Assert.AreEqual("I cannot find the ring", result);
	}


	[Test]
	public void TestLookAtGemInInventory()
	{
		string result = _lookCommand.Execute(_player, new string[] { "look", "at", "gem", "in", "inventory" });
		Assert.AreEqual("A shiny gem", result);
	}

	[Test]
	public void TestLookAtGemInBag()
	{
		string result = _lookCommand.Execute(_player, new string[] { "look", "at", "sword", "in", "bag" });
		Assert.AreEqual("A sharp sword", result);
	}

	[Test]
	public void TestLookAtItemInNoBag()
	{
		string result = _lookCommand.Execute(_player, new string[] { "look", "at", "sword", "in", "box" });
		Assert.AreEqual("I cannot find the box", result);
	}

	[Test]
	
	public void TestLookAtNoGemInBag()
	{
		string result = _lookCommand.Execute(_player, new string[] { "look", "at", "gem", "in", "bag" });
		Assert.AreEqual("I cannot find the gem", result);
	}


	[Test]
	public void TestInvalidLook()
	{
		string result = _lookCommand.Execute(_player, new string[] { "look", "around" });
		Assert.AreEqual("I don't know how to look like that", result);
	}
}
