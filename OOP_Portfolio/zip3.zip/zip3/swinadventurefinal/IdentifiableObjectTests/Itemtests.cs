﻿using NUnit.Framework;

[TestFixture]
public class ItemTests
{
    private Item _sword;
    private Item _shield;

    [SetUp]
    public void Setup()
    {
        _sword = new Item(new string[] { "sword", "blade" }, "a sword", "A sharp blade.");
        _shield = new Item(new string[] { "shield" }, "a shield", "A strong shield.");
    }

    [Test]
    public void TestItemIsIdentifiable()
    {
        Assert.IsTrue(_sword.AreYou("sword"));
        Assert.IsTrue(_sword.AreYou("blade"));
        Assert.IsFalse(_sword.AreYou("shield"));
    }

    [Test]
    public void TestShortDescription()
    {
        Assert.AreEqual("a sword (sword)", _sword.ShortDescription);
    }

    [Test]
    public void TestFullDescription()
    {
        Assert.AreEqual("A sharp blade.", _sword.FullDescription);
    }
}
