using NUnit.Framework;

[TestFixture]
public class IdentifiableObjectTests
{
    private IdentifiableObject obj;

    [SetUp]
    public void Setup()
    {
        obj = new IdentifiableObject(new string[] { "184", "Ved", "Makhijani" });
    }

    [Test]
    public void TestAreYou()
    {
        Assert.IsTrue(obj.AreYou("184"));
        Assert.IsTrue(obj.AreYou("Ved"));
        Assert.IsTrue(obj.AreYou("Makhijani"));
    }

    [Test]
    public void TestNotAreYou()
    {
        Assert.IsFalse(obj.AreYou("481"));
    }

    [Test]
    public void TestCaseSensitive()
    {
        Assert.IsTrue(obj.AreYou("Ved"));
        Assert.IsTrue(obj.AreYou("MAKHIJANI"));
    }

    [Test]
    public void TestFirstId()
    {
        Assert.AreEqual("184", obj.FirstId);
    }

    [Test]
    public void TestFirstIdWithNoIDs()
    {
        obj = new IdentifiableObject(new string[] { });
        Assert.AreEqual(string.Empty, obj.FirstId);
    }

    [Test]
    public void TestAddId()
    {
        obj = new IdentifiableObject(new string[] { "Seekers", "Athol", "Keith", "Bruce" });
        obj.AddIdentifier("Mary");
        Assert.IsTrue(obj.AreYou("Mary"));
    }

    [Test]
    public void TestPrivilegeEscalation()
    {
        obj = new IdentifiableObject(new string[] { "184", "Ved" });
        obj.PrivilegeEscalation("2184");
        Assert.AreEqual("1", obj.FirstId);
    }
}
